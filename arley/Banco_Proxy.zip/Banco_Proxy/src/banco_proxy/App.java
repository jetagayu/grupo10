package banco_proxy;

public class App {

    public static void main(String[] args) {
        Cuenta c = new Cuenta(1, "misionTic", 100);
        ICuenta cuentaProxy = new CuentaProxy(new CuentaBancoA());
        cuentaProxy.mostrarSaldo(c);
        c = cuentaProxy.depositarDinero(c, 50);
        c = cuentaProxy.retirarDinero(c, 20);
        cuentaProxy.mostrarSaldo(c);		
	}    
}
