package disco;

public class CD extends Disco{

    @Override
    public String descripcion(){
     return "CD Contenido: " + this.getContenido() + "duración: " +  this.getDuracion();
    }

    public String description() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }   
}
