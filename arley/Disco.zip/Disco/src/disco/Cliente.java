package disco;

public class Cliente{

    private DVD prototipoDVD;
    private CD prototipoCD;

    public void crearProtipo(){
        prototipoDVD = new DVD();
        prototipoDVD.setContenido("Peliculas");
        prototipoDVD.setDuracion("2:30");
        System.out.println("Prototipo:\n " + prototipoDVD.descripcion() + "\n");
        prototipoCD = new CD();
        prototipoCD.setContenido("Canciones");
        prototipoCD.setDuracion("1:30");
        System.out.println("Prototipo:\n " + prototipoCD.descripcion() + "\n");
    }
    public static void main(String[] args) throws CloneNotSupportedException{
        Cliente fabrica = new Cliente();
        fabrica.crearProtipo();
        Disco cloneCD1 = fabrica.prototipoCD.clone();
        System.out.println("Clone 1: \n" + cloneCD1.descripcion()+ "\n");
        
        Disco cloneDVD1 = fabrica.prototipoDVD.clone();
        cloneDVD1.setContenido("Documentales");
        cloneDVD1.setDuracion("1:00");
        System.out.println("Clone 1: \n" + cloneDVD1.descripcion() + "\n");
    }    
} 