package disco;

public class DVD extends Disco{

    public String descripcion(){
     return "DVD Contenido: " + this.getContenido() + "duración: " +  this.getDuracion();
    }
}
