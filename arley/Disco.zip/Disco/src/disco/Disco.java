package disco;

public abstract class Disco implements Cloneable{
    
    private String contenido;
    private String duracion;

    public Disco clone() throws CloneNotSupportedException{
        return (Disco) super.clone();
    }
    public abstract String descripcion();
    
    public String getContenido(){
        return contenido;
    }
    public void setContenido(String contenido){
        this.contenido = contenido;
    }
    public String getDuracion(){
        return duracion;
    }
    public void setDuracion(String duracion){
        this.duracion = duracion;
    }
}